#-*-coding:utf-8-*-
from appium import webdriver

class Launcher:

    def __init__(self):
        # 自动化测试平台
        self.automationName = 'XCUITest'
        # 平台名称
        self.platformName = 'iOS'
        # 设备名称
        self.deviceName = 'iPhone X'    # iPhone
        # self.deviceName = 'iPhone'  # iPhone 6plus
        # 设备版本
        self.platformVersion = '12.1'   # 9.3
        # self.platformVersion = '9.3'    # iPhone 6plus
        # 设备udid(901130617b3b2e1347beaba150fdf33871430c21 iphone 6Plus)
        self.udid = '421c3dc31fac5f1f375998bcc7801064e91d5245'   # iphone X

        # app identifier 已安装的app ID
        self.app = 'com.lvtainyuan.MallApp'
        # 绑定id
        self.bundleId = 'com.xie.wda.lib'
        # 服务器端口地址
        self.url = 'http://127.0.0.1:4723/wd/hub'
        # 超时时间
        self.newCommandTimeout = 60
        # 是否不重新安装启动
        self.noReset = True

        # 驱动
        self.run1 = None

    def get_driver(self):
        desired_capabilities = {
                'automationName': self.automationName,
                'deviceName': self.deviceName,
                'platformVersion': self.platformVersion,
                'udid':self.udid,
                'platformName': self.platformName,
                # 'browserName': 'safari'
                'app': self.app,
                'onReset': True,
                "xcodeOrgId": "CU5W8BV24X",
                "xcodeSigningId": "iPhone Developer"
                }
        self.driver = webdriver.Remote(self.url, desired_capabilities)
        return self.driver

if __name__=="__main__":
    a = Launcher()
    # a.get_driver().find_element_by_name(u"农场基地").click()
    a.driver.find_element_by_id("signup choice").click()
    str1 = a.driver.find_elements_by_name(u"请输入手机号码")
    str1[0].send_keys("13533880000")
    a.driver.find_element_by_id(u"下一步").click()