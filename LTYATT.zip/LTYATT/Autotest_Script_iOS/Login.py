#-*-coding:utf-8-*-
import Launcher_Setting

class Login:


    def __init__(self):
        self.driver = Launcher_Setting.Launcher().get_driver()

    def login(self):
        self.driver.
        return
