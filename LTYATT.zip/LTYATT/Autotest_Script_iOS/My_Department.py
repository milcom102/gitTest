#-*-coding:utf-8-*-
import Launcher_Setting
from selenium.common.exceptions import NoSuchElementException

class Department:

    def __init__(self):
        self.driver = Launcher_Setting.Launcher().get_driver()

    def add_section(self):
        try:
            self.driver.find_element_by_name(u"我的机构").click()
            self.driver.find_element_by_name(u"+").click()
            self.driver.find_element_by_ios_predicate(u'value=="请输入机构名称"').send_keys(u"莫哈维iOS")
            self.driver.find_element_by_ios_predicate(u'value=="请输入联系人"').send_keys(u"二哈iOS")
            self.driver.find_element_by_ios_predicate(u'value=="请输入手机号"').send_keys(u"13466778899")
            self.driver.find_element_by_ios_predicate(u'value=="请输入邮箱"').send_keys(u"abc@163.com")
            self.driver.find_element_by_ios_predicate(u'value=="请输入手机号"').send_keys(u"13466778899")
            self.driver.find_element_by_name(u"请选择").click()
            self.driver.find_elements_by_ios_predicate()
            self.driver.swipe()
        except NoSuchElementException:
            self.add_section()

    def test(self):
        value = self.driver.find_elements_by_ios_predicate(u'value=="预售产品"').count()
        count = self.driver.find_elements_by_ios_predicate('type=="XCUIElementTypeStaticText"').count()
        index = self.driver.find_elements_by_ios_predicate('type=="XCUIElementTypeStaticText"').index(1)
        print "value:%s" % value
        print "count:%s" % count
        print "index:%s" % index
